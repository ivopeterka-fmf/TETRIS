
package igraTetris;

public enum Liki {
     Nič, ZLik,SLik,Palčka,TLik,Kvadrat,LLik,ZrcalniL
}
