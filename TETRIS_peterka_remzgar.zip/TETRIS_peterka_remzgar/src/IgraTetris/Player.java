
package igraTetris;

public class Player {
    String name;
    int score;
    
    public Player(String nameIn,int scoreIn)
    {
        name=nameIn;
        score=scoreIn;
    }
}
